# project
The landing page project

# languages
-HTML
-CSS
-JAVASCRIPT

# NEW FUNCTIONALITES
-navbar
-active state
-scrolling

# the process
In the project we created a static landing page to a dynamic one through the use of javascript.